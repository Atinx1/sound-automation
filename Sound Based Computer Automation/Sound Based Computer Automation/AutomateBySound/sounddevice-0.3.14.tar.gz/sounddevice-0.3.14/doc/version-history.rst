Version History
===============

.. currentmodule:: sounddevice

.. default-role:: py:obj

.. include:: ../NEWS.rst

.. default-role::
